<?php 
	/*Update these credentials*/
 	define('MERCHANT_ID', '');
 	define('ACCESS_CODE', '');
 	define('WORKING_KEY', '');
?>