$(document).ready(function() {
  $('#lightgallery').lightGallery({
    pager: true
  });
});