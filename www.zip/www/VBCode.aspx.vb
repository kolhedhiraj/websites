﻿
Partial Class VBCode
    Inherits System.Web.UI.Page

End Class
