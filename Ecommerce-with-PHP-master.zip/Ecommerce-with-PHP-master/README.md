# Ecommerce-with-PHP
This is a web application which was developed with PHP. Here I used PHP, Javascript, AJAX and MySQL for databse.
