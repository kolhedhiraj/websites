<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/lib/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/lib/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/lib/select2/css/select2.min.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/lib/jquery.bxslider/jquery.bxslider.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/lib/owl.carousel/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/lib/jquery-ui/jquery-ui.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/css/animate.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/css/reset.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/css/style.css" />
<link rel="stylesheet" type="text/css" href="assets/mcom/assets/css/responsive.css" />