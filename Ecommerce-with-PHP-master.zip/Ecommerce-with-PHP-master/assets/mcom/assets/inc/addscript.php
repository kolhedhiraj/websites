<!-- Script-->
<script type="text/javascript" src="assets/mcom/assets/lib/jquery/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/lib/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/lib/select2/js/select2.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/lib/jquery.bxslider/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/lib/owl.carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/lib/jquery.countdown/jquery.countdown.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/js/jquery.actual.min.js"></script>
<script type="text/javascript" src="assets/mcom/assets/js/theme-script.js"></script>
<script type="text/javascript" src="assets/js/custom.js"></script>
