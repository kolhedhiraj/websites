package info.androidhive.paytmgateway.app;

public class Constants {
    public static final String DB_NAME = "paytm.androidhive";
    public static final String ORDER_STATUS_COMPLETED = "COMPLETED";
    public static final String ORDER_STATUS_FAILED = "FAILED";
    public static final String ORDER_STATUS_PROCESSING = "PROCESSING";
}
