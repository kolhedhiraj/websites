package info.androidhive.paytmgateway.networking.model;

import java.util.List;

public class PrepareOrderRequest {
    public List<OrderItem> orderItems;
}
