package info.androidhive.paytmgateway.networking.model;

public class LoginRequest {
    public String email;
    public String password;
}
