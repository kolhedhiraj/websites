package info.androidhive.paytmgateway.networking.model;

public class Transaction {
    public String id;
    public String status;
    public Order order;
    public String created_at;
}
