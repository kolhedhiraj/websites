package info.androidhive.paytmgateway.networking.model;

public class ChecksumResponse {
    public String checksum;
}
