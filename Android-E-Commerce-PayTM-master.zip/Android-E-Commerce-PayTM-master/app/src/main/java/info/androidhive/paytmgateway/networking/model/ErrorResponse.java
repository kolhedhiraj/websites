package info.androidhive.paytmgateway.networking.model;

public class ErrorResponse {
    public String error;
}
